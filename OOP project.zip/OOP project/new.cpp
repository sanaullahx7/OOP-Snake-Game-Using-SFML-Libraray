#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <iostream>
#include "WordleGame.h"
#include "Keyboard.h"
#include "Button.h"
#include "GameOverState.h"
#include "Sound.h"
#include "Constants.h"
#include "Invalid.h"

// Utility function to load words
bool loadWords(const std::string& filename, std::vector<std::string>& words) {
    std::ifstream file(filename);
    if (!file.is_open()) return false;
    std::string word;
    while (file >> word) {
        if (word.length() == 5) words.push_back(word);
    }
    return true;
}

int main() {
    // Setup SFML window
    sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Wajahat's Wordle Game");
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Error loading font!" << std::endl;
        return -1;
    }
   
    // Load words from file
    std::vector<std::string> words;
    if (!loadWords("words.txt", words)) {
        std::cerr << "Error loading words from file!" << std::endl;
        return -1;
    }

    std::srand(static_cast<unsigned>(std::time(nullptr)));
    std::string targetWord = words[std::rand() % words.size()];

    // Create game components
    WordleGame game(targetWord);
    Keyboard keyboard(font);

    // Create Invalid class instance
    Invalid invalidMessage(font);

    // Buttons for menu and in-game UI

    Button startButton(sf::Vector2f(MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT),
        sf::Vector2f(WINDOW_WIDTH / 2 - MENU_BUTTON_WIDTH / 2, WINDOW_HEIGHT / 2 - 100),
        font, "Start Game");

    Button exitButton(sf::Vector2f(MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT),
        sf::Vector2f(WINDOW_WIDTH / 2 - MENU_BUTTON_WIDTH / 2, WINDOW_HEIGHT / 2 + 200),
        font, "Exit");

    Button soundToggleButton(sf::Vector2f(MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT),
        sf::Vector2f(WINDOW_WIDTH / 2 - MENU_BUTTON_WIDTH / 2, WINDOW_HEIGHT / 2 + 50),
        font, "Sound");


    Button giveUpButton(sf::Vector2f(MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT),
        sf::Vector2f(WINDOW_WIDTH / 2 - MENU_BUTTON_WIDTH / 2, 0),
        font, "Give Up");

    Button soundToggleGame(sf::Vector2f(MENU_BUTTON_WIDTH - 10, MENU_BUTTON_HEIGHT),
        sf::Vector2f((WINDOW_WIDTH / 2 - MENU_BUTTON_WIDTH / 2) - 200 , 0),
        font, "Sound");

    Button ExitButtongame(sf::Vector2f(MENU_BUTTON_WIDTH - 10, MENU_BUTTON_HEIGHT),
        sf::Vector2f((WINDOW_WIDTH / 2 - MENU_BUTTON_WIDTH / 2) + 210, 0),
        font, "Exit");


    SoundManager soundManager;

    // Load sounds
    soundManager.loadSound("success", "success.wav");
    soundManager.loadSound("failure", "failure.wav");
    soundManager.loadSound("Invalid", "wrong.wav");

    // Play background music
    if (!soundManager.playBackgroundMusic("background_music.wav")) {
        std::cerr << "Error loading background music!" << std::endl;
        return -1;
    }

    bool inGame = false;
    bool isGameOver = false;
    bool isSoundOn = true;
    if (isSoundOn) {
        soundToggleGame.setColor(sf::Color::Green);  // Green for sound ON
        soundToggleButton.setColor(sf::Color::Green);  // Green for sound ON
    }
    else {
        soundToggleGame.setColor(sf::Color::Red);    // Red for sound OFF
        soundToggleButton.setColor(sf::Color::Red);    // Red for sound OFF

    }
    GameOverState* gameOverState = nullptr;

    // Main game loop
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) window.close();

            // Handle sound toggle
            if (!inGame && !isGameOver && event.type == sf::Event::MouseButtonPressed &&
                event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                if (soundToggleButton.isClicked(mousePos)) {
                    isSoundOn = !isSoundOn;
                    soundManager.toggleSound();
                    if (isSoundOn) {
                        soundToggleButton.setColor(sf::Color::Green);  // Green for sound ON
                    }
                    else {
                        soundToggleButton.setColor(sf::Color::Red);    // Red for sound OFF
                    }
                }
            }

            // Game over handling
            if (isGameOver) {
                if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    if (gameOverState->isRetryClicked(mousePos)) {
                        inGame = true;
                        isGameOver = false;
                        delete gameOverState;
                        gameOverState = nullptr;
                        // Get a new target word and reset the game
                        targetWord = words[std::rand() % words.size()];
                        game.resetGame(targetWord);
                        std::cout << targetWord;
                        keyboard.reset();
                        invalidMessage.clearMessage(); // Clear any error message
                    } else if (gameOverState->isExitClicked(mousePos)) {
                        window.close();
                    }
                }
            }
            // Handle in-game input
            else if (inGame) {
                if (event.type == sf::Event::TextEntered) {
                    char typedKey = static_cast<char>(std::toupper(event.text.unicode));
                    if (typedKey >= 'A' && typedKey <= 'Z') {
                        game.addCharacter(typedKey);
                        // Do not update keyboard state yet
                    }
                    if (typedKey == '\b') {
                        game.removeCharacter();
                        // Do not update keyboard state yet
                    }


                }

                if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Enter) {
                    if (!game.validateWord(game.getCurrentGuess(), words)) {
                        invalidMessage.setMessage("Invalid guess! Please try again.");
                        soundManager.playSound("Invalid");
                    }
                    else {
                        invalidMessage.clearMessage(); // Clear error if guess is valid

                        // Submit guess and process results
                        game.submitGuess(keyboard, words);

                        // Update keyboard state for submitted word
                        for (char ch : game.getCurrentGuess()) {
                            if (targetWord.find(ch) != std::string::npos) {
                                keyboard.updateKeyState(ch, 1); 
                            }
                            else {
                                keyboard.updateKeyState(ch, -1); 
                            }
                        }

                        if (game.isGameOver()) {
                            isGameOver = true;
                            std::string resultMessage = game.isGameWon() ? "Congratulations!\n You Won!" :
                                "You Lost!\n The word was: " + targetWord;
                            gameOverState = new GameOverState(font, resultMessage);
                            soundManager.playSound(game.isGameWon() ? "success" : "failure");
                        }
                    }
                }

                // Handle virtual keyboard clicks
                if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    char clickedKey = keyboard.getClickedKey(mousePos);
                    if (clickedKey != '\0') {
                        if (clickedKey == '\n') {
                            if (!game.validateWord(game.getCurrentGuess(), words)) {
                                invalidMessage.setMessage("Invalid guess! Please try again." + targetWord);
                                soundManager.playSound("Invalid");
                            }
                            else {
                                invalidMessage.clearMessage();
                                game.submitGuess(keyboard, words);

                                // Update keyboard state for submitted word
                                for (char ch : game.getCurrentGuess()) {
                                    if (targetWord.find(ch) != std::string::npos) {
                                        
                                        keyboard.updateKeyState(ch, 1); // Example: '1' for correct character
                                    }
                                    else {
                                        keyboard.updateKeyState(ch, -1); // Example: '-1' for incorrect character
                                    }
                                }

                                if (soundToggleGame.isClicked(mousePos)) {
                                    isSoundOn = !isSoundOn;
                                    soundManager.toggleSound();
                                    if (isSoundOn) {
                                        soundToggleGame.setColor(sf::Color::Green);  // Green for sound ON
                                    }
                                    else {
                                        soundToggleGame.setColor(sf::Color::Red);    // Red for sound OFF
                                    }
                                }
                                if (ExitButtongame.isClicked(mousePos)) {
                                    window.close();
                                }

                                if (game.isGameOver()) {
                                    isGameOver = true;
                                    std::string resultMessage = game.isGameWon() ? "Congratulations!\nYou Won!" :
                                        "You Lost!\n The word was: " + targetWord;
                                    gameOverState = new GameOverState(font, resultMessage);
                                    soundManager.playSound(game.isGameWon() ? "success" : "failure");
                                }
                            }
                        }
                        else if (clickedKey == '\b') {
                            game.removeCharacter();
                        }
                        else {
                            game.addCharacter(clickedKey);
                        }
                    }
                }
            }

            else if (inGame) {
                if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);

                    // Handle "Give Up" button
                    if (giveUpButton.isClicked(mousePos)) {
                        isGameOver = true;
                        std::string resultMessage = "You Gave Up!\n The word was: " + targetWord;
                        gameOverState = new GameOverState(font, resultMessage);
                        soundManager.playSound("failure");
                    }
                }
            }
            // Handle menu screen interactions
            else {
                if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    if (startButton.isClicked(mousePos)) {
                        inGame = true;
                        targetWord = words[std::rand() % words.size()];
                        game.resetGame(targetWord);
                        keyboard.reset();
                        std::cout << targetWord;
                        invalidMessage.clearMessage(); // Clear any error message
                    } else if (exitButton.isClicked(mousePos)) {
                        window.close();
                    }
                }
            }
            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);

                // Check if "Give Up" button is clicked
                if (giveUpButton.isClicked(mousePos)) {
                    isGameOver = true;
                    std::string resultMessage = "You Gave Up!\n The word was: " + targetWord;
                    gameOverState = new GameOverState(font, resultMessage);
                    soundManager.playSound("failure"); 
                }
                // Sound Of during game
                if (soundToggleGame.isClicked(mousePos)) {
                    isSoundOn = !isSoundOn;
                    soundManager.toggleSound();
                    if (isSoundOn) {
                        soundToggleGame.setColor(sf::Color::Green);  // Green for sound ON
                    }
                    else {
                        soundToggleGame.setColor(sf::Color::Red);    // Red for sound OFF
                    }
                }

                if (ExitButtongame.isClicked(mousePos)) {
                    window.close();
                }

            }

        }

        // Render logic
        window.clear(sf::Color:: Black);
        if (isGameOver) {
            gameOverState->draw(window);
        } else if (inGame) {
            game.draw(window, font);
            keyboard.draw(window);
            invalidMessage.draw(window); 
            giveUpButton.draw(window);
            soundToggleGame.draw(window);
            ExitButtongame.draw(window);
           
        } else {
            startButton.draw(window);
            exitButton.draw(window);
            soundToggleButton.draw(window);
        }
        window.display();
    }

    if (gameOverState) delete gameOverState;
    return 0;
}
