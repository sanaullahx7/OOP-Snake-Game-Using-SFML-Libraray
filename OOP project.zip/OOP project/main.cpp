#include "GameBoy.h"

int main() {
    GameBoy gameBoy;
    gameBoy.RunMenu();
    return 0;
}

