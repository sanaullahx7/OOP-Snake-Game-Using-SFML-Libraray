#include "GameBoy.h"

GameBoy::GameBoy()
    : window(sf::VideoMode(1920, 1080), "Snake Game"), selectedOption(0),
      difficulty("Medium"), snakeGame(1920, 1080) {
    RunLoadingScreen();
    InitMenu();
}

void GameBoy::RunLoadingScreen() {
    if (!introSoundBuffer.loadFromFile("Trimmed_Loading_Sound.ogg")) {
        std::cerr << "Failed to load intro sound!" << std::endl;
        return;
    }
    introSound.setBuffer(introSoundBuffer);
    introSound.play();

    sf::Font loadingFont;
    if (!loadingFont.loadFromFile("KnightWarrior-w16n8.otf")) {
        std::cerr << "Failed to load loading screen font!" << std::endl;
        return;
    }

    sf::Text loadingText("Loading", loadingFont, 50);
    loadingText.setFillColor(sf::Color::White);
    loadingText.setPosition(850, 500);

    sf::CircleShape dots[3];
    float dotRadius = 10.0f;
    float spacing = 20.0f;
    for (int i = 0; i < 3; ++i) {
        dots[i].setRadius(dotRadius);
        dots[i].setFillColor(sf::Color::White);
        dots[i].setPosition(850 + 100 + i * (2 * dotRadius + spacing), 550);
    }

    sf::Clock clock;
    sf::Clock animationClock;
    float animationTime = 0.0f;

    while (window.isOpen() && clock.getElapsedTime().asSeconds() < 5) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return;
            }
        }

        animationTime += animationClock.restart().asSeconds();
        for (int i = 0; i < 3; ++i) {
            float scale = 1.0f + 0.5f * std::sin(animationTime * 5.0f + i);
            dots[i].setScale(scale, scale);
        }

        window.clear();
        window.draw(loadingText);
        for (int i = 0; i < 3; ++i) {
            window.draw(dots[i]);
        }
        window.display();
    }

    introSound.stop();
}

void GameBoy::InitMenu() {
    // Load the background texture
    if (!backgroundTexture.loadFromFile("clear-snake-game-character.png")) {
        std::cerr << "Failed to load background image: clear-snake-game-character.png" << std::endl;
    } else {
        backgroundSprite.setTexture(backgroundTexture);
        backgroundSprite.setScale(
            static_cast<float>(window.getSize().x) / backgroundTexture.getSize().x,
            static_cast<float>(window.getSize().y) / backgroundTexture.getSize().y
        );
    }

    if (!font.loadFromFile("KnightWarrior-w16n8.otf")) {
        std::cerr << "Failed to load font!" << std::endl;
    }

    std::string options[] = {"Start Game", "Set Difficulty", "Tutorial", "Exit"};
    for (int i = 0; i < 4; ++i) {
        menuOptions[i].setFont(font);
        menuOptions[i].setString(options[i]);
        menuOptions[i].setCharacterSize(50);
        menuOptions[i].setPosition(800, 400 + i * 100);
    }

    difficultyDisplay.setFont(font);
    difficultyDisplay.setCharacterSize(30);
    difficultyDisplay.setFillColor(sf::Color::White);
    difficultyDisplay.setPosition(10, 10);

    tutorialText.setFont(font);
    tutorialText.setCharacterSize(30);
    tutorialText.setFillColor(sf::Color::White);
    tutorialText.setPosition(100, 100);
    tutorialText.setString(
        "How to Play:\n\n"
        "1. Use arrow keys to move the snake.\n"
        "2. Eat red food to grow and score.\n"
        "3. Avoid hitting walls or yourself.\n"
        "4. Bonus food offers extra points!\n\n"
        "Press ESC to return to the main menu."
    );
}

void GameBoy::RunMenu() {
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::KeyPressed) {
                if (inTutorial) {
                    if (event.key.code == sf::Keyboard::Escape) {
                        inTutorial = false;
                    }
                } else {
                    if (event.key.code == sf::Keyboard::Up) {
                        selectedOption = (selectedOption + 3) % 4;
                    } else if (event.key.code == sf::Keyboard::Down) {
                        selectedOption = (selectedOption + 1) % 4;
                    } else if (event.key.code == sf::Keyboard::Enter) {
                        if (selectedOption == 0) {
                            snakeGame.SetDifficulty(difficulty);
                            snakeGame.Init();
                            RunGame();
                        } else if (selectedOption == 1) {
                            SetDifficulty();
                        } else if (selectedOption == 2) {
                            inTutorial = true;
                        } else if (selectedOption == 3) {
                            window.close();
                        }
                    }
                }
            }
        }

        window.clear();
        if (inTutorial) {
            window.draw(tutorialText);
        } else {
            window.draw(backgroundSprite); // Draw the background sprite
            for (int i = 0; i < 4; ++i) {
                menuOptions[i].setFillColor(i == selectedOption ? sf::Color::Yellow : sf::Color::White);
                window.draw(menuOptions[i]);
            }
            difficultyDisplay.setString("Current Difficulty: " + difficulty);
            window.draw(difficultyDisplay);
        }
        window.display();
    }
}

void GameBoy::SetDifficulty() {
    std::string levels[] = {"Easy", "Medium", "Hard"};
    int selectedLevel = 1;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Up) {
                    selectedLevel = (selectedLevel + 2) % 3;
                } else if (event.key.code == sf::Keyboard::Down) {
                    selectedLevel = (selectedLevel + 1) % 3;
                } else if (event.key.code == sf::Keyboard::Enter) {
                    difficulty = levels[selectedLevel];
                    return;
                }
            }
        }

        window.clear();
        for (int i = 0; i < 3; ++i) {
            sf::Text level(levels[i], font, 30);
            level.setFillColor(i == selectedLevel ? sf::Color::Yellow : sf::Color::White);
            level.setPosition(800, 400 + i * 100);
            window.draw(level);
        }
        window.display();
    }
}

void GameBoy::RunGame() {
    sf::Clock clock;
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
            snakeGame.HandleInput(event);
        }

        float deltaTime = clock.restart().asSeconds();
        snakeGame.Update(deltaTime);

        window.clear();
        snakeGame.Render(window);
        window.display();
    }
}

