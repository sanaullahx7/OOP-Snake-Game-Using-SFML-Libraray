#ifndef GAMEBOY_H
#define GAMEBOY_H

#include "SnakeGame.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>

class GameBoy {
private:
    sf::RenderWindow window;
    sf::Texture backgroundTexture;
    sf::Sprite backgroundSprite;
    sf::Font font;
    sf::Text menuOptions[4];
    sf::Text difficultyDisplay;
    sf::Text tutorialText;
    int selectedOption;
    SnakeGame snakeGame;
    std::string difficulty;
    bool inTutorial;

    sf::SoundBuffer introSoundBuffer;
    sf::Sound introSound;

    void RunLoadingScreen();
    void InitMenu();
    void SetDifficulty();
    void RunGame();

public:
    GameBoy();
    void RunMenu();
};

#endif

