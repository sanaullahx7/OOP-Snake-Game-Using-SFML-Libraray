#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Game {
public:
    virtual void Init() = 0;
    virtual void Update(float deltaTime) = 0;
    virtual void Render(sf::RenderWindow& window) = 0;
    virtual void HandleInput(sf::Event event) = 0;
    virtual ~Game() = default;
};

#endif

