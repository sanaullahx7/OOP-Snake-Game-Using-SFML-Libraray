#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <cstdlib>
#include <string>
#include<cmath>
#include <fstream> //file handling

class Game {
public:
    virtual void Init() = 0;
    virtual void Update(float deltaTime) = 0;
    virtual void Render(sf::RenderWindow& window) = 0;
    virtual void HandleInput(sf::Event event) = 0;
    virtual ~Game() = default;
};

class SnakeGame : public Game {
private:
    static const int MAX_SEGMENTS = 200;
    static const int NUM_ACHIEVEMENTS = 4;
      int highScore;
      std::string highScoreFile = "highscore.txt"; // High score file

    sf::RectangleShape snake[MAX_SEGMENTS];
    sf::Vector2i positions[MAX_SEGMENTS];
    int snakeLength;
    sf::Vector2i direction;
    sf::Vector2i foodPosition;
    sf::RectangleShape food;
    int gridSize;
    int gridWidth;
    int gridHeight;
    int score;
    float updateInterval;
    float elapsedTime;
    float survivalTime;
    bool isGameOver;
    bool paused;
  // Bonus food variables
sf::RectangleShape bonusFood;
sf::Vector2i bonusFoodPosition;
bool isBonusFoodVisible = false;
float bonusFoodTimer = 0.0f;
float bonusFoodDuration = 10.0f;  // Bonus food stays visible for 5 seconds
float bonusFoodSpawnInterval = 15.0f;  // Bonus food spawns every 15 seconds
float bonusFoodSpawnTimer = 0.0f;

    sf::Font font;
    sf::Text scoreText;
    sf::Text pauseText;
    sf::Text gameOverText;
    sf::Text restartOption;

    sf::SoundBuffer eatSoundBuffer;
    sf::Sound eatSound;

    sf::SoundBuffer gameOverSoundBuffer;
    sf::Sound gameOverSound;

    sf::SoundBuffer achievementSoundBuffer;
    sf::Sound achievementSound;

    sf::RectangleShape topWall, bottomWall, leftWall, rightWall;

    // Achievements
    bool achievements[NUM_ACHIEVEMENTS] = {false};
    const char* achievementDescriptions[NUM_ACHIEVEMENTS] = {
        "Score 50 Points",
        "Survive 1 Minute",
        "Grow to 10 Segments",
        "Score 100 Points on Hard"
    };

    std::string difficulty;

    
    void CheckCollisions() {
        for (int i = 1; i < snakeLength; ++i) {
            if (positions[0] == positions[i]) {
                isGameOver = true;
                gameOverSound.play();
            }
        }
        if (positions[0].x < 0 || positions[0].y < 0 ||
            positions[0].x >= gridWidth || positions[0].y >= gridHeight) {
            isGameOver = true;
            gameOverSound.play();
        }
        if (positions[0] == foodPosition) {
            score += 10;
            GrowSnake();
            SpawnFood();
            eatSound.play();
        }
    }
   void SpawnFood() {
    // Define a fixed-size array to store available positions
    const int MAX_GRID_POSITIONS = gridWidth * gridHeight;
    sf::Vector2i availablePositions[MAX_GRID_POSITIONS];
    int availableCount = 0;

    // Generate all possible positions on the grid
    for (int x = 0; x < gridWidth; ++x) {
        for (int y = 0; y < gridHeight; ++y) {
            sf::Vector2i position(x, y);
            bool isOccupied = false;

            // Check if the position is occupied by the snake
            for (int i = 0; i < snakeLength; ++i) {
                if (positions[i] == position) {
                    isOccupied = true;
                    break;
                }
            }

            // Add position to available positions if not occupied
            if (!isOccupied) {
                availablePositions[availableCount] = position;
                availableCount++;
            }
        }
    }

    // If there are no available positions, end the game (edge case)
    if (availableCount == 0) {
        isGameOver = true;
        std::cout << "Game Over: No space left for food!" << std::endl;
        return;
    }

    // Randomly select a position from the available positions
    int randomIndex = std::rand() % availableCount;
    foodPosition = availablePositions[randomIndex];
    food.setPosition(foodPosition.x * gridSize, foodPosition.y * gridSize);
}
void SpawnBonusFood() {
    bool validPosition = false;

    while (!validPosition) {
        bonusFoodPosition.x = std::rand() % gridWidth;
        bonusFoodPosition.y = std::rand() % gridHeight;

        validPosition = true; // Assume valid
        for (int i = 0; i < snakeLength; ++i) {
            if (positions[i] == bonusFoodPosition || foodPosition == bonusFoodPosition) {
                validPosition = false; // Bonus food overlaps snake or normal food
                break;
            }
        }
    }

    bonusFood.setPosition(bonusFoodPosition.x * gridSize, bonusFoodPosition.y * gridSize);
    isBonusFoodVisible = true;  // Make the bonus food visible
    bonusFoodTimer = 0.0f;  // Reset bonus food timer
}

    void GrowSnake() {
        if (snakeLength < MAX_SEGMENTS) {
            positions[snakeLength] = positions[snakeLength - 1];
            snake[snakeLength].setSize(sf::Vector2f(gridSize, gridSize));
            snake[snakeLength].setFillColor(sf::Color::Green);
            snakeLength++;
        }
    }

    void SetupWalls() {
        float thickness = 10.0f;

        topWall.setSize(sf::Vector2f(gridWidth * gridSize, thickness));
        topWall.setFillColor(sf::Color::Blue);
        topWall.setPosition(0, 0);

        bottomWall.setSize(sf::Vector2f(gridWidth * gridSize, thickness));
        bottomWall.setFillColor(sf::Color::Blue);
        bottomWall.setPosition(0, gridHeight * gridSize - thickness);

        leftWall.setSize(sf::Vector2f(thickness, gridHeight * gridSize));
        leftWall.setFillColor(sf::Color::Blue);
        leftWall.setPosition(0, 0);

        rightWall.setSize(sf::Vector2f(thickness, gridHeight * gridSize));
        rightWall.setFillColor(sf::Color::Blue);
        rightWall.setPosition(gridWidth * gridSize - thickness, 0);
    }
void LoadHighScore() {
        std::ifstream file(highScoreFile);
        if (file.is_open()) {
            file >> highScore;
            file.close();
        } else {
            highScore = 0; // Default to 0 if file doesn't exist
        }
    }
// Function to save the high score to file
    void SaveHighScore() {
        std::ofstream file(highScoreFile);
        if (file.is_open()) {
            file << highScore;
            file.close();
        }
    }
    void CheckAchievements() {
        if (score >= 50 && !achievements[0]) {
            achievements[0] = true;
            achievementSound.play();
        }

        if (survivalTime >= 60.0f && !achievements[1]) {
            achievements[1] = true;
            achievementSound.play();
        }

        if (snakeLength >= 10 && !achievements[2]) {
            achievements[2] = true;
            achievementSound.play();
        }

        if (difficulty == "Hard" && score >= 100 && !achievements[3]) {
            achievements[3] = true;
            achievementSound.play();
        }
    }

public:
    SnakeGame(int screenWidth, int screenHeight)
        : gridSize(20), score(0), updateInterval(0.2f), elapsedTime(0.0f),
          survivalTime(0.0f), isGameOver(false), paused(false), snakeLength(3),
          difficulty("Medium") {
        gridWidth = screenWidth / gridSize;
        gridHeight = screenHeight / gridSize;

        for (int i = 0; i < MAX_SEGMENTS; ++i) {
            snake[i].setSize(sf::Vector2f(gridSize, gridSize));
            snake[i].setFillColor(sf::Color::Green);
        }
        direction = {1, 0};
        SetupWalls();
        
          LoadHighScore(); 
    }
    void SetDifficulty(const std::string& diff) {
        difficulty = diff;
        if (difficulty == "Easy")
            updateInterval = 0.2f;
        else if (difficulty == "Medium")
            updateInterval = 0.1f;
        else if (difficulty == "Hard")
            updateInterval = 0.05f;
    }



    void Init() override {
        snakeLength = 3;
        isGameOver = false;
        paused = false;
        score = 0;
        survivalTime = 0;

        for (int i = 0; i < snakeLength; ++i) {
            positions[i] = {gridWidth / 2 - i, gridHeight / 2};
            snake[i].setPosition(positions[i].x * gridSize, positions[i].y * gridSize);
        }

        food.setSize(sf::Vector2f(gridSize, gridSize));
        food.setFillColor(sf::Color::Red);
        SpawnFood();
         // Initialize bonus food
bonusFood.setSize(sf::Vector2f(gridSize * 1.5f, gridSize * 1.5f));
bonusFood.setFillColor(sf::Color::Yellow);  // Bonus food is yellow
isBonusFoodVisible = false;  // Initially, bonus food is not visible

        if (!font.loadFromFile("KnightWarrior-w16n8.otf")) {
            std::cerr << "Failed to load font!" << std::endl;
        }

        scoreText.setFont(font);
        scoreText.setCharacterSize(30);
        scoreText.setFillColor(sf::Color::White);
        scoreText.setPosition(10, 10);

        pauseText.setFont(font);
        pauseText.setCharacterSize(40);
        pauseText.setFillColor(sf::Color::Yellow);
        pauseText.setPosition(gridWidth * gridSize / 4, gridHeight * gridSize / 2);

        gameOverText.setFont(font);
        gameOverText.setCharacterSize(40);
        gameOverText.setFillColor(sf::Color::Red);
        gameOverText.setPosition(gridWidth * gridSize / 2 - 150, gridHeight * gridSize / 2 - 50);

        restartOption.setFont(font);
        restartOption.setCharacterSize(30);
        restartOption.setFillColor(sf::Color::White);
        restartOption.setPosition(gridWidth * gridSize / 2 - 200, gridHeight * gridSize / 2 + 20);

        if (!achievementSoundBuffer.loadFromFile("achievement-video-game-type-1-230515.wav")) {
            std::cerr << "Failed to load achievement sound!" << std::endl;
        }
        achievementSound.setBuffer(achievementSoundBuffer);

        if (!eatSoundBuffer.loadFromFile("mixkit-winning-a-coin-video-game-2069.wav")) {
            std::cerr << "Failed to load eating sound!" << std::endl;
        }
        eatSound.setBuffer(eatSoundBuffer);

        if (!gameOverSoundBuffer.loadFromFile("sad.wav")) {
            std::cerr << "Failed to load game over sound!" << std::endl;
        }
        gameOverSound.setBuffer(gameOverSoundBuffer);
    }

    void Update(float deltaTime) override {
        if (paused || isGameOver) return;

        elapsedTime += deltaTime;
        survivalTime += deltaTime;
  // Handle bonus food spawn and visibility
    bonusFoodSpawnTimer += deltaTime;
    if (isBonusFoodVisible) {
        bonusFoodTimer += deltaTime;
        if (bonusFoodTimer >= bonusFoodDuration) {
            isBonusFoodVisible = false;  // Hide bonus food after its duration
        }
    } else if (bonusFoodSpawnTimer >= bonusFoodSpawnInterval) {
        SpawnBonusFood();
        bonusFoodSpawnTimer = 0.0f;  // Reset spawn timer
    }
        if (elapsedTime >= updateInterval) {
            elapsedTime = 0.0f;

            for (int i = snakeLength - 1; i > 0; --i) {
                positions[i] = positions[i - 1];
            }
            positions[0].x += direction.x;
            positions[0].y += direction.y;

            for (int i = 0; i < snakeLength; ++i) {
                snake[i].setPosition(positions[i].x * gridSize, positions[i].y * gridSize);
            }

            CheckCollisions();
            if (isBonusFoodVisible && positions[0] == bonusFoodPosition) {
            score += 50;  // Award bonus points
            GrowSnake();  // Grow the snake
            isBonusFoodVisible = false;  // Hide bonus food
        }

            CheckAchievements();
            if (score > highScore) {
                highScore = score;
                SaveHighScore(); // Save the new high score
            }
        }
    }

    void Render(sf::RenderWindow& window) override {
    if (paused) {
        pauseText.setString("Paused. Press P to Resume");
        window.draw(pauseText);
        return;
    }

    if (isGameOver) {
        gameOverText.setString("Game Over!");
        restartOption.setString("Press R to Restart or E to Exit");
        window.draw(gameOverText);
        window.draw(restartOption);
        return;
    }

    window.draw(topWall);
    window.draw(bottomWall);
    window.draw(leftWall);
    window.draw(rightWall);

    for (int i = 0; i < snakeLength; ++i) {
        window.draw(snake[i]);
    }
    window.draw(food);
    if (isBonusFoodVisible) {
        window.draw(bonusFood);  // Draw bonus food if visible
    }

    scoreText.setString("Score: " + std::to_string(score) + "   High Score: " + std::to_string(highScore));
    window.draw(scoreText);

    // Local declaration of achievementTitle
    sf::Text achievementTitle("Achievements:", font, 20);
    achievementTitle.setFillColor(sf::Color::White);
    achievementTitle.setPosition(10, 50);
    window.draw(achievementTitle);

    for (int i = 0; i < NUM_ACHIEVEMENTS; ++i) {
        sf::Text achievementText(achievementDescriptions[i], font, 20);
        achievementText.setFillColor(achievements[i] ? sf::Color::Yellow : sf::Color::White);
        achievementText.setPosition(10, 80 + i * 30);
        window.draw(achievementText);
    }
}


    void HandleInput(sf::Event event) override {
        if (event.type == sf::Event::KeyPressed) {
            if (isGameOver) {
                if (event.key.code == sf::Keyboard::R) {
                    Init();
                } else if (event.key.code == sf::Keyboard::E) {
                    std::exit(0);
                }
            } else if (event.key.code == sf::Keyboard::P) {
                paused = !paused;
            } else if (!paused) {
                if (event.key.code == sf::Keyboard::Up && direction.y == 0) direction = {0, -1};
                if (event.key.code == sf::Keyboard::Down && direction.y == 0) direction = {0, 1};
                if (event.key.code == sf::Keyboard::Left && direction.x == 0) direction = {-1, 0};
                if (event.key.code == sf::Keyboard::Right && direction.x == 0) direction = {1, 0};
            }
        }
    }
};


class GameBoy {
private:
    sf::RenderWindow window;
    sf::Texture backgroundTexture;
    sf::Sprite backgroundSprite;
    sf::Font font;
    sf::Text menuOptions[4]; // Increased size for additional option
    sf::Text difficultyDisplay;
    sf::Text tutorialText; // Text to display tutorial instructions
    int selectedOption;
    SnakeGame snakeGame;
    std::string difficulty;
    bool inTutorial = false; // Tracks if the user is viewing the tutorial
       sf::SoundBuffer introSoundBuffer; // Declare intro sound buffer
    sf::Sound introSound;             
public:
    GameBoy()
        : window(sf::VideoMode(1920, 1080), "Snake Game"), selectedOption(0),
          difficulty("Medium"), snakeGame(1920, 1080) {}
void RunLoadingScreen() {
    // Load the intro sound
    if (!introSoundBuffer.loadFromFile("Trimmed_Loading_Sound.ogg")) {
        std::cerr << "Failed to load intro sound!" << std::endl;
        return; // Exit early if sound fails
    }
    introSound.setBuffer(introSoundBuffer);
    introSound.play();

    // Create loading screen text
    sf::Font loadingFont;
    if (!loadingFont.loadFromFile("KnightWarrior-w16n8.otf")) {
        std::cerr << "Failed to load font for loading screen!" << std::endl;
        return; // Exit early if font fails
    }

    sf::Text loadingText("Loading", loadingFont, 50);
    loadingText.setFillColor(sf::Color::White);
    loadingText.setPosition(850, 500); // Centered on the screen

    // Create animated dots
    sf::CircleShape dots[3];
    float dotRadius = 10.0f;
    float spacing = 20.0f;
    for (int i = 0; i < 3; ++i) {
        dots[i].setRadius(dotRadius);
        dots[i].setFillColor(sf::Color::White);
        dots[i].setPosition(850 + 100 + i * (2 * dotRadius + spacing), 550);
    }

    sf::Clock clock; // Track total loading time
    sf::Clock animationClock; // Separate clock for smooth animation
    float animationTime = 0.0f;

    // Run the loading screen for 5 seconds max or until the window is closed
    while (window.isOpen() && clock.getElapsedTime().asSeconds() < 5) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return;
            }
        }

        // Update animation
        animationTime += animationClock.restart().asSeconds();
        for (int i = 0; i < 3; ++i) {
            float scale = 1.0f + 0.5f * std::sin(animationTime * 5.0f + i * 1.0f);
            dots[i].setScale(scale, scale);
        }

        // Clear and draw the loading screen
        window.clear();
        window.draw(loadingText);
        for (int i = 0; i < 3; ++i) {
            window.draw(dots[i]);
        }
        window.display();
    }

    introSound.stop(); // Stop the sound after the loading screen ends
}

    void InitMenu() {
        if (!backgroundTexture.loadFromFile("clear-snake-game-character.png")) {
            std::cerr << "Failed to load background image!" << std::endl;
        }
        backgroundSprite.setTexture(backgroundTexture);
        backgroundSprite.setScale(1920.0f / backgroundTexture.getSize().x, 1080.0f / backgroundTexture.getSize().y);

        if (!font.loadFromFile("KnightWarrior-w16n8.otf")) {
            std::cerr << "Failed to load font!" << std::endl;
        }

        std::string options[] = {"Start Game", "Set Difficulty", "Tutorial", "Exit"};
        for (int i = 0; i < 4; ++i) {
            menuOptions[i].setFont(font);
            menuOptions[i].setString(options[i]);
            menuOptions[i].setCharacterSize(50);
            menuOptions[i].setPosition(800, 400 + i * 100);
        }

        difficultyDisplay.setFont(font);
        difficultyDisplay.setCharacterSize(30);
        difficultyDisplay.setFillColor(sf::Color::White);
        difficultyDisplay.setPosition(10, 10);

        tutorialText.setFont(font);
        tutorialText.setCharacterSize(30);
        tutorialText.setFillColor(sf::Color::White);
        tutorialText.setPosition(100, 100);
        tutorialText.setString(
            "How to Play:\n\n"
            "1. Use arrow keys to move the snake.\n"
            "2. Eat the red food to grow and score points.\n"
            "3. Avoid hitting the walls or yourself.\n"
            "4. Bonus food appears occasionally for extra points.\n\n"
            "Press ESC to return to the main menu."
        );
    }

  void RunMenu() {
    // Display the loading screen
    RunLoadingScreen(); 

    // Initialize the menu options after the loading screen
    InitMenu();

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::KeyPressed) {
                if (inTutorial) {
                    if (event.key.code == sf::Keyboard::Escape) {
                        inTutorial = false; // Exit the tutorial
                    }
                } else {
                    if (event.key.code == sf::Keyboard::Up) {
                        selectedOption = (selectedOption + 3) % 4;
                    } else if (event.key.code == sf::Keyboard::Down) {
                        selectedOption = (selectedOption + 1) % 4;
                    } else if (event.key.code == sf::Keyboard::Enter) {
                        if (selectedOption == 0) {
                            snakeGame.SetDifficulty(difficulty);
                            snakeGame.Init();
                            RunGame();
                        } else if (selectedOption == 1) {
                            SetDifficulty();
                        } else if (selectedOption == 2) {
                            inTutorial = true; // Open the tutorial screen
                        } else if (selectedOption == 3) {
                            window.close();
                        }
                    }
                }
            }
        }

        window.clear();
        if (inTutorial) {
            // Render tutorial screen
            window.draw(tutorialText);
        } else {
            // Render main menu
            window.draw(backgroundSprite);

            for (int i = 0; i < 4; ++i) {
                menuOptions[i].setFillColor(i == selectedOption ? sf::Color::Yellow : sf::Color::White);
                window.draw(menuOptions[i]);
            }

            difficultyDisplay.setString("Current Difficulty: " + difficulty);
            window.draw(difficultyDisplay);
        }
        window.display();
    }
}

    void SetDifficulty() {
        std::string levels[] = {"Easy", "Medium", "Hard"};
        int selectedLevel = 1;

        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    window.close();
                } else if (event.type == sf::Event::KeyPressed) {
                    if (event.key.code == sf::Keyboard::Up) {
                        selectedLevel = (selectedLevel + 2) % 3;
                    } else if (event.key.code == sf::Keyboard::Down) {
                        selectedLevel = (selectedLevel + 1) % 3;
                    } else if (event.key.code == sf::Keyboard::Enter) {
                        difficulty = levels[selectedLevel];
                        return;
                    }
                }
            }

            window.clear();
            window.draw(backgroundSprite);

            sf::Text difficultyText("Select Difficulty: ", font, 40);
            difficultyText.setFillColor(sf::Color::White);
            difficultyText.setPosition(700, 300);
            window.draw(difficultyText);

            for (int i = 0; i < 3; ++i) {
                sf::Text level(levels[i], font, 30);
                level.setFillColor(i == selectedLevel ? sf::Color::Yellow : sf::Color::White);
                level.setPosition(800, 400 + i * 100);
                window.draw(level);
            }

            window.display();
        }
    }

    void RunGame() {
        sf::Clock clock;

        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    window.close();
                }
                snakeGame.HandleInput(event);
            }

            float deltaTime = clock.restart().asSeconds();
            snakeGame.Update(deltaTime);

            window.clear();
            window.draw(backgroundSprite);
            snakeGame.Render(window);
            window.display();
        }
    }
    
};

int main() {
    GameBoy gameBoy;
    gameBoy.RunMenu();
    return 0;
}
g++ o.cpp -o h -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio


