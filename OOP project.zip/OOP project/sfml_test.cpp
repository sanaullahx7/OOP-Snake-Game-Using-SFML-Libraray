#include <SFML/Graphics.hpp>

int main()
{
    // Create a window with the title "SFML Test" and size 800x600
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Test");

    // Main loop that continues until the window is closed
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Close window when requested
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Clear the window with a blue color
        window.clear(sf::Color::Blue);

        // Display the contents on the screen
        window.display();
    }

    return 0;
}

