#include "SnakeGame.h"
#include <fstream>
#include <iostream>
#include <cstdlib>

SnakeGame::SnakeGame(int screenWidth, int screenHeight)
    : gridSize(20), score(0), updateInterval(0.2f), elapsedTime(0.0f),
      survivalTime(0.0f), isGameOver(false), paused(false), snakeLength(3),
      difficulty("Medium") {
    gridWidth = screenWidth / gridSize;
    gridHeight = screenHeight / gridSize;

    for (int i = 0; i < MAX_SEGMENTS; ++i) {
        snake[i].setSize(sf::Vector2f(gridSize, gridSize));
        snake[i].setFillColor(sf::Color::Green);
    }
    direction = {1, 0};
    SetupWalls();
    LoadHighScore();
}

void SnakeGame::SetupWalls() {
    float thickness = 10.0f;

    topWall.setSize(sf::Vector2f(gridWidth * gridSize, thickness));
    topWall.setFillColor(sf::Color::Blue);
    topWall.setPosition(0, 0);

    bottomWall.setSize(sf::Vector2f(gridWidth * gridSize, thickness));
    bottomWall.setFillColor(sf::Color::Blue);
    bottomWall.setPosition(0, gridHeight * gridSize - thickness);

    leftWall.setSize(sf::Vector2f(thickness, gridHeight * gridSize));
    leftWall.setFillColor(sf::Color::Blue);
    leftWall.setPosition(0, 0);

    rightWall.setSize(sf::Vector2f(thickness, gridHeight * gridSize));
    rightWall.setFillColor(sf::Color::Blue);
    rightWall.setPosition(gridWidth * gridSize - thickness, 0);
}

void SnakeGame::LoadHighScore() {
    std::ifstream file(highScoreFile);
    if (file.is_open()) {
        file >> highScore;
        file.close();
    } else {
        highScore = 0;
    }
}

void SnakeGame::SaveHighScore() {
    std::ofstream file(highScoreFile);
    if (file.is_open()) {
        file << highScore;
        file.close();
    }
}

void SnakeGame::Init() {
  std::srand(static_cast<unsigned>(std::time(nullptr))); 
    snakeLength = 3;
    isGameOver = false;
    paused = false;
    score = 0;
    survivalTime = 0;

    for (int i = 0; i < snakeLength; ++i) {
        positions[i] = {gridWidth / 2 - i, gridHeight / 2};
        snake[i].setPosition(positions[i].x * gridSize, positions[i].y * gridSize);
    }

    food.setSize(sf::Vector2f(gridSize, gridSize));
    food.setFillColor(sf::Color::Red);
    SpawnFood();

    bonusFood.setSize(sf::Vector2f(gridSize * 1.5f, gridSize * 1.5f));
    bonusFood.setFillColor(sf::Color::Yellow);
    isBonusFoodVisible = false;

    LoadHighScore();

    if (!font.loadFromFile("KnightWarrior-w16n8.otf")) {
        std::cerr << "Failed to load font!" << std::endl;
    }

    scoreText.setFont(font);
    scoreText.setCharacterSize(30);
    scoreText.setFillColor(sf::Color::White);
    scoreText.setPosition(10, 10);

    pauseText.setFont(font);
    pauseText.setCharacterSize(40);
    pauseText.setFillColor(sf::Color::Yellow);
    pauseText.setPosition(gridWidth * gridSize / 4, gridHeight * gridSize / 2);

    gameOverText.setFont(font);
    gameOverText.setCharacterSize(40);
    gameOverText.setFillColor(sf::Color::Red);
    gameOverText.setPosition(gridWidth * gridSize / 2 - 150, gridHeight * gridSize / 2 - 50);

    restartOption.setFont(font);
    restartOption.setCharacterSize(30);
    restartOption.setFillColor(sf::Color::White);
    restartOption.setPosition(gridWidth * gridSize / 2 - 200, gridHeight * gridSize / 2 + 20);

    if (!achievementSoundBuffer.loadFromFile("achievement-video-game-type-1-230515.wav")) {
        std::cerr << "Failed to load achievement sound!" << std::endl;
    }
    achievementSound.setBuffer(achievementSoundBuffer);

    if (!eatSoundBuffer.loadFromFile("mixkit-winning-a-coin-video-game-2069.wav")) {
        std::cerr << "Failed to load eating sound!" << std::endl;
    }
    eatSound.setBuffer(eatSoundBuffer);

    if (!gameOverSoundBuffer.loadFromFile("sad.wav")) {
        std::cerr << "Failed to load game over sound!" << std::endl;
    }
    gameOverSound.setBuffer(gameOverSoundBuffer);
}

void SnakeGame::SetDifficulty(const std::string& diff) {
    difficulty = diff;
    if (difficulty == "Easy")
        updateInterval = 0.2f;
    else if (difficulty == "Medium")
        updateInterval = 0.1f;
    else if (difficulty == "Hard")
        updateInterval = 0.05f;
}
void SnakeGame::SpawnFood() {
    const int MAX_GRID_POSITIONS = gridWidth * gridHeight;
    sf::Vector2i availablePositions[MAX_GRID_POSITIONS];
    int availableCount = 0;

    for (int x = 0; x < gridWidth; ++x) {
        for (int y = 0; y < gridHeight; ++y) {
            sf::Vector2i position(x, y);
            bool isOccupied = false;

            for (int i = 0; i < snakeLength; ++i) {
                if (positions[i] == position) {
                    isOccupied = true;
                    break;
                }
            }

            if (!isOccupied) {
                availablePositions[availableCount++] = position;
            }
        }
    }

    if (availableCount == 0) {
        isGameOver = true;
        std::cout << "No available space for food! Game Over!" << std::endl;
        return;
    }

    int randomIndex = std::rand() % availableCount;
    foodPosition = availablePositions[randomIndex];
    food.setPosition(foodPosition.x * gridSize, foodPosition.y * gridSize);

    // Debug message
    std::cout << "Food spawned at (" << foodPosition.x << ", " << foodPosition.y << ")" << std::endl;
}


void SnakeGame::SpawnBonusFood() {
    bool validPosition = false;
    while (!validPosition) {
        bonusFoodPosition.x = std::rand() % gridWidth;
        bonusFoodPosition.y = std::rand() % gridHeight;

        validPosition = true;
        for (int i = 0; i < snakeLength; ++i) {
            if (positions[i] == bonusFoodPosition || foodPosition == bonusFoodPosition) {
                validPosition = false;
                break;
            }
        }
    }

    bonusFood.setPosition(bonusFoodPosition.x * gridSize, bonusFoodPosition.y * gridSize);
    isBonusFoodVisible = true;
    bonusFoodTimer = 0.0f;
}

void SnakeGame::GrowSnake() {
    if (snakeLength < MAX_SEGMENTS) {
        positions[snakeLength] = positions[snakeLength - 1];
        snake[snakeLength].setSize(sf::Vector2f(gridSize, gridSize));
        snake[snakeLength].setFillColor(sf::Color::Green);
        snakeLength++;
    }
}
void SnakeGame::CheckCollisions() {
    // Collision with itself
    for (int i = 1; i < snakeLength; ++i) {
        if (positions[0] == positions[i]) {
            isGameOver = true;
            gameOverSound.play();
        }
    }

    // Collision with walls
    if (positions[0].x < 0 || positions[0].y < 0 ||
        positions[0].x >= gridWidth || positions[0].y >= gridHeight) {
        isGameOver = true;
        gameOverSound.play();
    }

    // Eating food
    if (positions[0] == foodPosition) {
        score += 10;
        GrowSnake();
        SpawnFood(); // Ensure SpawnFood is called after eating
        eatSound.play();
    }
}



void SnakeGame::CheckAchievements() {
    if (score >= 50 && !achievements[0]) {
        achievements[0] = true;
        achievementSound.play();
    }

    if (survivalTime >= 60.0f && !achievements[1]) {
        achievements[1] = true;
        achievementSound.play();
    }

    if (snakeLength >= 10 && !achievements[2]) {
        achievements[2] = true;
        achievementSound.play();
    }

    if (difficulty == "Hard" && score >= 100 && !achievements[3]) {
        achievements[3] = true;
        achievementSound.play();
    }
}
void SnakeGame::Update(float deltaTime) {
    if (paused || isGameOver) return;

    // Increment timers
    elapsedTime += deltaTime;
    survivalTime += deltaTime;

    // Handle bonus food visibility and spawn intervals
    bonusFoodSpawnTimer += deltaTime;
    if (isBonusFoodVisible) {
        bonusFoodTimer += deltaTime;
        if (bonusFoodTimer >= bonusFoodDuration) {
            isBonusFoodVisible = false; // Hide bonus food after its duration
        }
    } else if (bonusFoodSpawnTimer >= bonusFoodSpawnInterval) {
        SpawnBonusFood();
        bonusFoodSpawnTimer = 0.0f; // Reset bonus food spawn timer
    }

    // Update snake movement at regular intervals
    if (elapsedTime >= updateInterval) {
        elapsedTime = 0.0f;

        // Move the snake body
        for (int i = snakeLength - 1; i > 0; --i) {
            positions[i] = positions[i - 1];
        }

        // Move the snake head
        positions[0].x += direction.x;
        positions[0].y += direction.y;

        // Update snake's rectangle positions
        for (int i = 0; i < snakeLength; ++i) {
            snake[i].setPosition(positions[i].x * gridSize, positions[i].y * gridSize);
        }

        // Check for collisions (snake, food, walls)
        CheckCollisions();

        // Handle bonus food consumption
        if (isBonusFoodVisible && positions[0] == bonusFoodPosition) {
            score += 50;         // Award bonus points
            GrowSnake();         // Grow the snake
            isBonusFoodVisible = false; // Remove the bonus food
        }

        // Check achievements after score or survival updates
        CheckAchievements();

        // Save high score if beaten
        if (score > highScore) {
            highScore = score;
            SaveHighScore();
        }
    }
}


void SnakeGame::Render(sf::RenderWindow& window) {
    if (paused) {
        pauseText.setString("Paused. Press P to Resume");
        window.draw(pauseText);
        return;
    }

    if (isGameOver) {
        gameOverText.setString("Game Over!");
        restartOption.setString("Press R to Restart or E to Exit");
        window.draw(gameOverText);
        window.draw(restartOption);
        return;
    }

    window.draw(topWall);
    window.draw(bottomWall);
    window.draw(leftWall);
    window.draw(rightWall);

    // Draw the snake
    for (int i = 0; i < snakeLength; ++i) {
        window.draw(snake[i]);
    }

    // Debug: Check food position before drawing
    std::cout << "Rendering food at (" << food.getPosition().x << ", " << food.getPosition().y << ")" << std::endl;

    // Draw the food
    window.draw(food);

    // Draw the bonus food if visible
    if (isBonusFoodVisible) {
        window.draw(bonusFood);
    }

    // Draw score and high score
    scoreText.setString("Score: " + std::to_string(score) + "   High Score: " + std::to_string(highScore));
    window.draw(scoreText);

    // Draw achievements
    sf::Text achievementTitle("Achievements:", font, 20);
    achievementTitle.setFillColor(sf::Color::White);
    achievementTitle.setPosition(10, 50);
    window.draw(achievementTitle);

    for (int i = 0; i < NUM_ACHIEVEMENTS; ++i) {
        sf::Text achievementText(achievementDescriptions[i], font, 20);
        achievementText.setFillColor(achievements[i] ? sf::Color::Yellow : sf::Color::White);
        achievementText.setPosition(10, 80 + i * 30);
        window.draw(achievementText);
    }
}

void SnakeGame::HandleInput(sf::Event event) {
    if (event.type == sf::Event::KeyPressed) {
        if (isGameOver) {
            if (event.key.code == sf::Keyboard::R) {
                Init();
            } else if (event.key.code == sf::Keyboard::E) {
                std::exit(0);
            }
        } else if (event.key.code == sf::Keyboard::P) {
            paused = !paused;
        } else if (!paused) {
            if (event.key.code == sf::Keyboard::Up && direction.y == 0) direction = {0, -1};
            if (event.key.code == sf::Keyboard::Down && direction.y == 0) direction = {0, 1};
            if (event.key.code == sf::Keyboard::Left && direction.x == 0) direction = {-1, 0};
            if (event.key.code == sf::Keyboard::Right && direction.x == 0) direction = {1, 0};
        }
    }
}

