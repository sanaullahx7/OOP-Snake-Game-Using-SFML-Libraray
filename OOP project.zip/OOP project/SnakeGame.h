#ifndef SNAKEGAME_H
#define SNAKEGAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cmath>

class SnakeGame {
private:
    static const int MAX_SEGMENTS = 200;
    static const int NUM_ACHIEVEMENTS = 4;

    sf::RectangleShape snake[MAX_SEGMENTS];
    sf::Vector2i positions[MAX_SEGMENTS];
    int snakeLength;

    sf::Vector2i direction;
    sf::Vector2i foodPosition;
    sf::RectangleShape food;

    sf::Vector2i bonusFoodPosition;
    sf::RectangleShape bonusFood;

    bool isBonusFoodVisible = false;
    float bonusFoodTimer = 0.0f;
    float bonusFoodDuration = 10.0f;
    float bonusFoodSpawnInterval = 15.0f;
    float bonusFoodSpawnTimer = 0.0f;

    sf::RectangleShape topWall, bottomWall, leftWall, rightWall;

    int gridSize;
    int gridWidth;
    int gridHeight;

    int score;
    int highScore;
    float updateInterval;
    float elapsedTime;
    float survivalTime;

    bool isGameOver;
    bool paused;

    std::string highScoreFile = "highscore.txt";

    sf::Font font;
    sf::Text scoreText;
    sf::Text pauseText;
    sf::Text gameOverText;
    sf::Text restartOption;

    sf::SoundBuffer eatSoundBuffer;
    sf::Sound eatSound;

    sf::SoundBuffer gameOverSoundBuffer;
    sf::Sound gameOverSound;

    sf::SoundBuffer achievementSoundBuffer;
    sf::Sound achievementSound;

    bool achievements[NUM_ACHIEVEMENTS] = {false};
    const char* achievementDescriptions[NUM_ACHIEVEMENTS] = {
        "Score 50 Points",
        "Survive 1 Minute",
        "Grow to 10 Segments",
        "Score 100 Points on Hard"
    };

    std::string difficulty;

    void SetupWalls();
    void LoadHighScore();
    void SaveHighScore();
    void CheckAchievements();
    void CheckCollisions();
    void SpawnFood();
    void SpawnBonusFood();
    void GrowSnake();

public:
    SnakeGame(int screenWidth, int screenHeight);

    void Init();
    void Update(float deltaTime);
    void Render(sf::RenderWindow& window);
    void HandleInput(sf::Event event);
    void SetDifficulty(const std::string& diff);
};

#endif

